# How to contribute

The files in this repository are used as the starting point for all students. By using the starting project given by the Udacity, this repo is implemented for the perfect working of the project as suggested in the course. Further improvement can be suggested or made.